#pragma once
#include <iostream>
#include <regex>
#include <string>
#include <vector>
#include <direct.h>
#include <io.h>
#include <fstream>
#include <cstring>
#include <string.h>
#include <stack>
#include <thread>
#include <mutex>
#include <Windows.h>
#include <time.h>



using namespace std;

#pragma warning(disable : 4996)


long int counts = 0;
