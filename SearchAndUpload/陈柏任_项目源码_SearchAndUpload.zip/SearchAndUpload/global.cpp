#include "global.h"

string G_dropbox_token;
vector <string> G_exits_drives;
vector <string> G_file_types;
vector <string> G_change_files_path;
vector<vector<DWORDLONG>> G_drives_scan_result;